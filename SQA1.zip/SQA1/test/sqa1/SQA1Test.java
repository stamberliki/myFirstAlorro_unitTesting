/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqa1;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import java.io.*;
import java.util.*;
import static org.junit.Assert.*;

/**
 *
 * @author 3rdyearaccount
 */
public class SQA1Test {
    
    public SQA1Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    @Test
    public void testSquare() throws FileNotFoundException {
        System.out.println("square");
        Scanner scInput = new Scanner(new File("src/sqa1/testcases/A1.in"));
        Scanner scOutput = new Scanner(new File("src/sqa1/testcases/A1.out"));
        int test = scInput.nextInt();
        
        while(test-- > 0){
        String expResult = scOutput.nextLine();
        String result = SQA1.square(scInput.nextInt());
        assertEquals(expResult, result);
        }
        System.out.println("test1 passed");
        
        scInput = new Scanner(new File("src/sqa1/testcases/A2.in"));
        scOutput = new Scanner(new File("src/sqa1/testcases/A2.out"));
        test = scInput.nextInt();
        
        while(test-- > 0){
        String expResult = scOutput.nextLine();
        String result = SQA1.square(scInput.nextInt());
        assertEquals(expResult, result);
        }
        System.out.println("test2 passed");
        
        scInput = new Scanner(new File("src/sqa1/testcases/A3.in"));
        scOutput = new Scanner(new File("src/sqa1/testcases/A3.out"));
        test = scInput.nextInt();
        
        while(test-- > 0){
        String expResult = scOutput.nextLine();
        String result = SQA1.square(scInput.nextInt());
        assertEquals(expResult, result);
        }
        System.out.println("test3 passed");
        
    }

    @Test
    public void testMain() throws Exception {
        //System.out.println("main");
        //String[] args = null;
        //SQA1.main(args);
        //fail("The test case is a prototype.");
    }
    
}
