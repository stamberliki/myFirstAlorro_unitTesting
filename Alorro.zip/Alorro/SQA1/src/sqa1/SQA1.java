package sqa1;

import java.io.*;
import java.util.*;

public class SQA1 {
    
    public static String square(int a){
        if (a<0) return "Invalid";
        else if (a>1000) return "Too big";
        return String.valueOf(a*a);
    }
    
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("src/sqa1/testcases/A1.in"));
        int test = scan.nextInt();
        int x;
        
        while(test-- > 0){
            System.out.println(square(scan.nextInt()));
        }
    }
}
